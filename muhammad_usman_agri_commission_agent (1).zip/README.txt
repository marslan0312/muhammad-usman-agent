MUHAMMAD USMAN AGRICULTURAL COMMISSION AGENT WEBSITE
=====================================================

FILES
- index.html : website content and image links
- style.css  : layout, colours and responsive mobile design

PREVIEW
1. Keep index.html and style.css in the same folder.
2. Double-click index.html to open in a browser.
3. Internet is needed to load the external photos.

BEFORE PUBLISHING
- WhatsApp / phone number is set to 03123762434 (WhatsApp link uses Pakistan international format).
- Replace info@example.com and add the correct city/mandi/office location.
- Replace "your-email@example.com" in the form action with the email that should receive enquiries. The form service may ask you to verify the email.
- Update products/services to match actual business activity. Product photos are illustrative; no stock or prices are confirmed.
- Confirm quantity, quality, rates, transport, payment and commission terms directly and in writing.

FREE GITHUB PAGES HOSTING
1. Sign in or create an account at https://github.com/
2. Create a PUBLIC repository named muhammad-usman-agri-commission-agent
3. Upload index.html and style.css to the repository's root and commit.
4. Go to Settings -> Pages.
5. Select "Deploy from a branch", branch "main", folder "/ (root)", then Save.
6. Wait a few minutes. GitHub Pages will show the published URL.

GOOGLE SEARCH
1. Open https://search.google.com/search-console/
2. Add your published URL using URL-prefix and verify ownership.
3. Use URL Inspection to request indexing.
Google decides if and when the website appears in search results; it may take time.

GitHub Pages gives a free github.io subdomain. A custom .com domain generally costs money. The static website needs an external form service to receive enquiries; GitHub Pages itself does not process forms.
